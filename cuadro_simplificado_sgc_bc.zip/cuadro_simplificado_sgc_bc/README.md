# Cuadro de construcción simplificado - SGC BC

Este parche modifica únicamente `/var/www/catastro/js/06-construcciones-medicion.js`.

Objetivo: que el cuadro de construcción y las etiquetas P1, P2, P3... usen un contorno simplificado para presentación, eliminando vértices intermedios sobre linderos rectos.

No modifica PostGIS, GeoServer, ni la geometría real del predio.

## Instalación

Subir `patch_cuadro_construccion_simplificado.sh` al servidor y ejecutar:

```bash
chmod +x patch_cuadro_construccion_simplificado.sh
sudo ./patch_cuadro_construccion_simplificado.sh /var/www/catastro/js/06-construcciones-medicion.js
```

Después recargar el navegador con Ctrl+F5.

## Parámetros internos

En el bloque inyectado se usan:

- toleranciaLinea: 0.15 m
- distanciaMinima: 0.02 m
- anguloRecto: 3°
- conservarEsquina: 20°

Si el cuadro todavía conserva puntos de más, subir toleranciaLinea a 0.25.
Si elimina esquinas importantes, bajar toleranciaLinea a 0.05 o subir conservarEsquina a 25.
