#!/usr/bin/env bash
set -euo pipefail

JS_FILE="${1:-/var/www/catastro/js/06-construcciones-medicion.js}"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [[ ! -f "$JS_FILE" ]]; then
  echo "ERROR: No existe el archivo: $JS_FILE" >&2
  exit 1
fi

cp "$JS_FILE" "${JS_FILE}.bak_cuadro_simplificado_${STAMP}"
echo "Respaldo creado: ${JS_FILE}.bak_cuadro_simplificado_${STAMP}"

python3 - "$JS_FILE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding='utf-8')

marker = "  async function cargarGeometriaEnMapaConstrucciones(clave, p) {"
helper = r'''
  // ============================================================
  // Cuadro de construcción simplificado
  // ------------------------------------------------------------
  // Limpia únicamente la geometría usada para calcular el cuadro
  // y las etiquetas de medición P1, P2, P3... No modifica PostGIS,
  // no modifica el GeoJSON original y no afecta la edición.
  // ============================================================
  function popupConstrDistanciaPuntos_(a, b) {
    const dx = Number(a[0]) - Number(b[0]);
    const dy = Number(a[1]) - Number(b[1]);
    return Math.sqrt(dx * dx + dy * dy);
  }

  function popupConstrDistanciaPuntoLinea_(p, a, b) {
    const ax = Number(a[0]), ay = Number(a[1]);
    const bx = Number(b[0]), by = Number(b[1]);
    const px = Number(p[0]), py = Number(p[1]);
    const dx = bx - ax, dy = by - ay;
    const len2 = dx * dx + dy * dy;
    if (len2 <= 0) return popupConstrDistanciaPuntos_(p, a);
    const t = ((px - ax) * dx + (py - ay) * dy) / len2;
    const qx = ax + t * dx;
    const qy = ay + t * dy;
    const ex = px - qx, ey = py - qy;
    return Math.sqrt(ex * ex + ey * ey);
  }

  function popupConstrAnguloInterior_(a, b, c) {
    const ux = Number(a[0]) - Number(b[0]);
    const uy = Number(a[1]) - Number(b[1]);
    const vx = Number(c[0]) - Number(b[0]);
    const vy = Number(c[1]) - Number(b[1]);
    const nu = Math.sqrt(ux * ux + uy * uy);
    const nv = Math.sqrt(vx * vx + vy * vy);
    if (nu <= 0 || nv <= 0) return 180;
    let cos = (ux * vx + uy * vy) / (nu * nv);
    cos = Math.max(-1, Math.min(1, cos));
    return Math.acos(cos) * 180 / Math.PI;
  }

  function popupConstrPuntosIguales_(a, b, tol) {
    return popupConstrDistanciaPuntos_(a, b) <= tol;
  }

  function popupConstrCerrarRing_(pts) {
    if (!pts.length) return pts;
    const first = pts[0];
    const last = pts[pts.length - 1];
    if (!popupConstrPuntosIguales_(first, last, 0.000001)) pts.push(first.slice());
    else pts[pts.length - 1] = first.slice();
    return pts;
  }

  function popupConstrSimplificarRingCuadro_(ring, opts) {
    const toleranciaLinea = Number(opts?.toleranciaLinea ?? 0.15); // metros UTM
    const distanciaMinima = Number(opts?.distanciaMinima ?? 0.02); // metros UTM
    const anguloRecto = Number(opts?.anguloRecto ?? 3.0);          // grados cerca de 180
    const conservarEsquina = Number(opts?.conservarEsquina ?? 20); // grados de cambio real

    if (!Array.isArray(ring) || ring.length < 4) return ring;

    // Quitar cierre para trabajar, eliminar duplicados cercanos y cerrar al final.
    let pts = ring.slice();
    if (popupConstrPuntosIguales_(pts[0], pts[pts.length - 1], 0.000001)) pts = pts.slice(0, -1);

    const dedup = [];
    for (const p of pts) {
      if (!dedup.length || !popupConstrPuntosIguales_(dedup[dedup.length - 1], p, distanciaMinima)) {
        dedup.push([Number(p[0]), Number(p[1])]);
      }
    }
    pts = dedup;
    if (pts.length < 3) return popupConstrCerrarRing_(pts);

    let cambio = true;
    let guard = 0;
    while (cambio && guard < 20 && pts.length > 3) {
      cambio = false;
      guard += 1;
      const salida = [];
      for (let i = 0; i < pts.length; i++) {
        const prev = pts[(i - 1 + pts.length) % pts.length];
        const curr = pts[i];
        const next = pts[(i + 1) % pts.length];
        const d1 = popupConstrDistanciaPuntos_(prev, curr);
        const d2 = popupConstrDistanciaPuntos_(curr, next);
        const ang = popupConstrAnguloInterior_(prev, curr, next);
        const cambioDireccion = Math.abs(180 - ang);
        const desvio = popupConstrDistanciaPuntoLinea_(curr, prev, next);

        const muyCerca = d1 <= distanciaMinima || d2 <= distanciaMinima;
        const casiRecto = cambioDireccion <= anguloRecto;
        const sobreLinderoRecto = desvio <= toleranciaLinea && cambioDireccion < conservarEsquina;

        if ((muyCerca || casiRecto || sobreLinderoRecto) && pts.length - salida.length > 3) {
          cambio = true;
          continue;
        }
        salida.push(curr);
      }
      pts = salida;
    }

    return popupConstrCerrarRing_(pts);
  }

  function popupConstrSimplificarGeomParaCuadro(geom32611, opts) {
    try {
      if (!geom32611 || !geom32611.clone || !geom32611.getType) return geom32611;
      const g = geom32611.clone();
      const tipo = g.getType();
      if (tipo === "Polygon") {
        const rings = g.getCoordinates().map((ring, idx) => {
          // Solo simplificamos el anillo exterior; huecos se conservan.
          return idx === 0 ? popupConstrSimplificarRingCuadro_(ring, opts) : ring;
        });
        return new ol.geom.Polygon(rings);
      }
      if (tipo === "MultiPolygon") {
        const polys = g.getCoordinates().map(poly => poly.map((ring, idx) => {
          return idx === 0 ? popupConstrSimplificarRingCuadro_(ring, opts) : ring;
        }));
        return new ol.geom.MultiPolygon(polys);
      }
      return g;
    } catch (e) {
      console.warn("No se pudo simplificar geometría para cuadro de construcción:", e);
      return geom32611;
    }
  }

'''

if 'function popupConstrSimplificarGeomParaCuadro' not in text:
    if marker not in text:
        raise SystemExit('No se encontró el punto de inserción: cargarGeometriaEnMapaConstrucciones')
    text = text.replace(marker, helper + marker, 1)

old = '''    if (popupConstrGeom32611) {
      popupConstrCalcularMedidasPredio(popupConstrGeom32611);
      const cuadro = popupConstrCalcularCuadro(popupConstrGeom32611);
      const el = document.getElementById("popupConstrCuadroBody");
      if (el) el.innerHTML = popupConstrHtmlCuadro(clave, cuadro, p);
    }'''
new = '''    if (popupConstrGeom32611) {
      const geomCuadro32611 = typeof popupConstrSimplificarGeomParaCuadro === "function"
        ? popupConstrSimplificarGeomParaCuadro(popupConstrGeom32611, {
            toleranciaLinea: 0.15,
            distanciaMinima: 0.02,
            anguloRecto: 3.0,
            conservarEsquina: 20
          })
        : popupConstrGeom32611;
      popupConstrCalcularMedidasPredio(geomCuadro32611);
      const cuadro = popupConstrCalcularCuadro(geomCuadro32611);
      const el = document.getElementById("popupConstrCuadroBody");
      if (el) el.innerHTML = popupConstrHtmlCuadro(clave, cuadro, p);
    }'''

if old not in text:
    if 'popupConstrSimplificarGeomParaCuadro(popupConstrGeom32611' not in text:
        raise SystemExit('No se encontró el bloque original para reemplazar.')
else:
    text = text.replace(old, new, 1)

path.write_text(text, encoding='utf-8')
print('OK: archivo actualizado:', path)
PY

echo "Listo. Recarga el navegador con Ctrl+F5."
